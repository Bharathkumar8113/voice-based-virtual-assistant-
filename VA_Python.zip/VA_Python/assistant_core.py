# assistant_core.py
import re
import random
import dateparser
from openai import OpenAI
from const import OPENAI_API_KEY

client = OpenAI(api_key=OPENAI_API_KEY)

TERMINATION_KEYWORDS = ["stop", "exit", "thank you", "thanks"]
BOOKING_KEYWORDS = ["book room", "book hotel", "hotel booking"]
NUMBER_WORDS = { "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                 "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10 }

def interpret_date(text):
    parsed_date = dateparser.parse(text)
    if parsed_date:
        return parsed_date.strftime("%B %d")
    return None

def extract_number(text):
    match = re.search(r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten)", text)
    if match:
        val = match.group(1)
        return int(val) if val.isdigit() else NUMBER_WORDS.get(val)
    return None

def generate_response(user_input, context={}):
    # Booking flow (simplified for browser)
    if any(k in user_input for k in BOOKING_KEYWORDS):
        return "Sure. When is your check-in date?", "booking_date"

    if context.get("expect") == "booking_date":
        date = interpret_date(user_input)
        if date:
            context["date"] = date
            return "Got it. How many guests?", "booking_guests"
        return "I couldn't understand the date. Please repeat.", "booking_date"

    if context.get("expect") == "booking_guests":
        guests = extract_number(user_input)
        if guests:
            context["guests"] = guests
            return "And how many nights?", "booking_nights"
        return "Please tell me the number of guests.", "booking_guests"

    if context.get("expect") == "booking_nights":
        nights = extract_number(user_input)
        if nights:
            context["nights"] = nights
            summary = f"Room booked for {context['guests']} guest(s) on {context['date']} for {nights} night(s)."
            return summary, None
        return "Please tell me how many nights.", "booking_nights"

    # General GPT response
    for attempt in range(2):
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Keep your responses concise (1-2 short sentences)."},
                    {"role": "user", "content": user_input}
                ],
                max_tokens=80,
                temperature=0.7,
            )
            return response.choices[0].message.content.strip(), None
        except:
            continue
    return "I'm having trouble responding right now.", None
