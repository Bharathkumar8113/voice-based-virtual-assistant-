import os
import re
import time
import random
import tempfile
import speech_recognition as sr
import playsound
import dateparser
from gtts import gTTS
from openai import OpenAI
from datetime import datetime, timedelta
from const import OPENAI_API_KEY

# Initialize OpenAI Client
client = OpenAI(api_key=OPENAI_API_KEY)

# Keywords
TERMINATION_KEYWORDS = ["stop", "exit", "thank you", "thanks"]
BOOKING_KEYWORDS = ["book room", "book hotel", "hotel booking"]
WAKE_WORD = "hey assistant"

NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10
}
# Speak using Google TTS
def speak(text):
    print(f"\n🧠 Assistant: {text}")
    tts = gTTS(text)
    with tempfile.NamedTemporaryFile(delete=True, suffix=".mp3") as fp:
        tts.save(fp.name)
        playsound.playsound(fp.name)

# Listen and return user voice as text
def listen(prompt=None):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        if prompt:
            speak(prompt)
        print("🎤 Listening...")
        try:
            audio = recognizer.listen(source, phrase_time_limit=6)
            text = recognizer.recognize_google(audio)
            print(f"👤 You: {text}\n")
            return text.lower()
        except sr.UnknownValueError:
            speak("Sorry, could you repeat that?")
        except sr.RequestError:
            speak("Speech service error.")
    return ""

# Wait for wake word
def wait_for_wake_word():
    while True:
        print("👂 Waiting for wake word...")
        text = listen()
        if WAKE_WORD in text:
            speak("Yes? How can I help?")
            return

# Parse date using dateparser
def interpret_date(text):
    parsed_date = dateparser.parse(text)
    if parsed_date:
        return parsed_date.strftime("%B %d")
    return None

# Extract number from text
def extract_number(text):
    match = re.search(r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten)", text)
    if match:
        val = match.group(1)
        return int(val) if val.isdigit() else NUMBER_WORDS.get(val)
    return None

# Room booking interaction
def handle_booking():
    speak("Okay. Let's start your room booking.")
    details = {"date": None, "guests": None, "nights": None}

    while not details["date"]:
        response = listen("When is your check-in date?")
        if response:
            details["date"] = interpret_date(response)

    while not details["guests"]:
        response = listen("How many guests?")
        if response:
            details["guests"] = extract_number(response)

    while not details["nights"]:
        response = listen("For how many nights?")
        if response:
            details["nights"] = extract_number(response)

    speak(f"Room booked for {details['guests']} guest(s) on {details['date']} for {details['nights']} night(s).")

# General ChatGPT-powered Q&A
def handle_general_query(user_input):
    for attempt in range(2):
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": user_input}],
                max_tokens=30,
                temperature=0.7,
            )
            answer = response.choices[0].message.content.strip()
            speak(answer)
            return
        except Exception as e:
            print("GPT error:", e)
            if attempt == 0:
                speak("Trying again...")
    speak("Sorry, I couldn't fetch an answer right now.")

# Session after wake word
def run_assistant_session():
    while True:
        user_input = listen()
        if not user_input:
            continue

        if any(keyword in user_input for keyword in TERMINATION_KEYWORDS):
            speak("Goodbye!")
            break

        if any(keyword in user_input for keyword in BOOKING_KEYWORDS):
            handle_booking()
        else:
            handle_general_query(user_input)

# Main loop
if __name__ == "__main__":
    speak("Voice assistant is ready. Say 'Hey Assistant' to begin.")
    while True:
        wait_for_wake_word()
        run_assistant_session()
