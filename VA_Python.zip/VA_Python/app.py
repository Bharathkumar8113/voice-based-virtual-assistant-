# app.py
from flask import Flask, render_template, request, jsonify  
from assistant_core import generate_response

app = Flask(__name__)
context = {}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/voice", methods=["POST"])
def handle_voice():
    user_input = request.json.get("text")
    assistant_reply, next_expect = generate_response(user_input, context)
    if next_expect:
        context["expect"] = next_expect
    else:
        context.clear()
    return jsonify({"reply": assistant_reply})

if __name__ == "__main__":
    app.run(debug=True)
