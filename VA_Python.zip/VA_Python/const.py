OPENAI_API_KEY = "Replace with your key"  # 
