# import os
# import time
# import speech_recognition as sr
# import pyttsx3
# from openai import OpenAI

# # ====== CONFIG ======
# OPENAI_API_KEY = "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"  # Replace this with your actual OpenAI key

# # ====== Initialize OpenAI Client ======
# client = OpenAI(api_key=OPENAI_API_KEY)

# # ====== Initialize Text-to-Speech Engine ======
# engine = pyttsx3.init()
# engine.setProperty('rate', 175)

# def speak(text):
#     print(f"\n🗣️ Assistant: {text}\n")
#     engine.say(text)
#     engine.runAndWait()

# # ====== Recognize Speech from Mic ======
# def listen():
#     r = sr.Recognizer()
#     with sr.Microphone() as source:
#         print("🎤 Listening...")
#         audio = r.listen(source, phrase_time_limit=6)

#     try:
#         text = r.recognize_google(audio)
#         print(f"👤 You: {text}\n")
#         return text
#     except sr.UnknownValueError:
#         print("🤖 Sorry, I didn’t catch that.\n")
#         speak("Sorry, could you please repeat that?")
#         return ""
#     except sr.RequestError:
#         print("❌ Speech recognition service error.\n")
#         speak("I'm having trouble with speech recognition.")
#         return ""

# # ====== Generate Response from OpenAI ======
# def get_openai_response(conversation):
#     try:
#         response = client.chat.completions.create(
#             model="gpt-3.5-turbo",
#             messages=conversation
#         )
#         reply = response.choices[0].message.content
#         return reply.strip()
#     except Exception as e:
#         print(f"⚠️ Error from OpenAI: {e}\n")
#         return "I'm having trouble processing that right now. Please try again."

# # ====== Main Assistant Logic ======
# def run_assistant():
#     conversation = [
#         {"role": "system", "content": "You are a helpful hotel receptionist assistant."}
#     ]

#     speak("Hello! How can I help you today?")

#     while True:
#         user_input = listen()
#         if not user_input:
#             continue

#         if "stop" in user_input.lower() or "exit" in user_input.lower():
#             speak("Okay, ending the session. Have a great day!")
#             break

#         conversation.append({"role": "user", "content": user_input})
#         response = get_openai_response(conversation)

#         if response:
#             conversation.append({"role": "assistant", "content": response})
#             speak(response)
#         else:
#             speak("Sorry, I didn’t get that.")

# # ====== Run It ======
# if __name__ == "__main__":
#     run_assistant()



# import os
# import time
# import speech_recognition as sr
# import pyttsx3
# from openai import OpenAI

# # ====== CONFIG ======
# OPENAI_API_KEY = "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"  # Replace with your actual key

# # ====== Initialize OpenAI Client ======
# client = OpenAI(api_key=OPENAI_API_KEY)

# # ====== Initialize Text-to-Speech Engine ======
# engine = pyttsx3.init()
# engine.setProperty('rate', 175)

# def speak(text):
#     print(f"\n🗣️ Assistant: {text}\n")
#     engine.say(text)
#     engine.runAndWait()

# def listen():
#     recognizer = sr.Recognizer()
#     with sr.Microphone() as source:
#         print("🎤 Listening...")
#         audio = recognizer.listen(source, phrase_time_limit=6)

#     try:
#         text = recognizer.recognize_google(audio)
#         print(f"👤 You: {text}\n")
#         return text.lower()
#     except sr.UnknownValueError:
#         print("🤖 Sorry, I didn’t catch that.\n")
#         speak("Sorry, could you please repeat that?")
#         return ""
#     except sr.RequestError:
#         print("❌ Speech recognition service error.\n")
#         speak("I'm having trouble with speech recognition.")
#         return ""

# # ====== Booking Info Tracker ======
# details = {
#     "date": None,
#     "nights": None,
#     "guests": None
# }

# TERMINATION_KEYWORDS = ["stop", "exit", "thank you", "thanks"]

# # ====== Main Assistant Logic ======
# def run_assistant():
#     speak("Hello! How can I help you today?")

#     while True:
#         user_input = listen()
#         if not user_input:
#             continue

#         if any(kw in user_input for kw in TERMINATION_KEYWORDS):
#             speak("Okay, ending the session. Have a great day!")
#             break

#         if not details["date"] and ("today" in user_input or "tomorrow" in user_input):
#             details["date"] = "tomorrow" if "tomorrow" in user_input else "today"
#             continue

#         if not details["nights"]:
#             for word in user_input.split():
#                 if word.isdigit():
#                     details["nights"] = int(word)
#                     break
#             if details["nights"]:
#                 continue

#         if not details["guests"]:
#             if "one" in user_input or "1" in user_input:
#                 details["guests"] = 1
#             elif "two" in user_input or "2" in user_input:
#                 details["guests"] = 2
#             elif "three" in user_input or "3" in user_input:
#                 details["guests"] = 3
#             elif "four" in user_input or "4" in user_input:
#                 details["guests"] = 4
#             if details["guests"]:
#                 continue

#         if all(details.values()):
#             speak(f"Thank you! Your room has been booked for {details['guests']} guest{'s' if details['guests'] > 1 else ''} starting {details['date']} for {details['nights']} night{'s' if details['nights'] > 1 else ''}. We look forward to your stay!")
#             break

#         # Fallback response if inputs are unclear
#         response = client.chat.completions.create(
#             model="gpt-3.5-turbo",
#             messages=[
#                 {"role": "system", "content": "You are a helpful hotel booking assistant."},
#                 {"role": "user", "content": user_input}
#             ]
#         )
#         reply = response.choices[0].message.content
#         speak(reply)

# # ====== Run It ======
# if __name__ == "__main__":
#     run_assistant()

