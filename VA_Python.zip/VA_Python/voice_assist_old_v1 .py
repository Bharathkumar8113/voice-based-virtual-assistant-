import os
import re
import time
import random
import speech_recognition as sr
import pyttsx3
from openai import OpenAI
from datetime import datetime, timedelta
from const import OPENAI_API_KEY

# Initialize OpenAI Client
client = OpenAI(api_key=OPENAI_API_KEY)

# Initialize TTS Engine
engine = pyttsx3.init()
engine.setProperty('rate', 175)

# Constants
TERMINATION_KEYWORDS = ["stop", "exit", "thank you", "thanks"]
BOOKING_KEYWORDS = ["book room", "book hotel", "hotel booking"]

# Number word mapping
NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10
}

# Speak

def speak(text):
    print(f"\n🗣️ Assistant: {text}\n")
    engine.say(text)
    engine.runAndWait()

# Listen

def listen(prompt=None):
    recognizer = sr.Recognizer()
    attempts = 0
    while attempts < 3:
        if prompt:
            speak(prompt)
        with sr.Microphone() as source:
            print("🎤 Listening...")
            audio = recognizer.listen(source, phrase_time_limit=6)
        try:
            text = recognizer.recognize_google(audio)
            print(f"👤 You: {text}\n")
            return text.lower()
        except sr.UnknownValueError:
            attempts += 1
            speak("Could you repeat?")
        except sr.RequestError:
            speak("Speech recognition error.")
            return ""
    speak("Let's try again later.")
    return ""

# Interpret Date

def interpret_date(text):
    today = datetime.today()
    if "today" in text:
        return today.strftime("%B %d")
    elif "tomorrow" in text:
        return (today + timedelta(days=1)).strftime("%B %d")
    elif "day after tomorrow" in text:
        return (today + timedelta(days=2)).strftime("%B %d")

    months = {
        'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
        'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
    }
    match = re.search(r"(\d{1,2})(st|nd|rd|th)?\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)?", text)
    if match:
        day = int(match.group(1))
        month = datetime.now().month if not match.group(3) else months.get(match.group(3))
        try:
            target_date = datetime(today.year, month, day)
            return target_date.strftime("%B %d")
        except:
            return None
    return None

# Extract Number

def extract_number(text):
    match = re.search(r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten)", text)
    if match:
        val = match.group(1)
        return int(val) if val.isdigit() else NUMBER_WORDS.get(val)
    return None

# Handle Booking

def handle_booking():
    details = {"date": None, "guests": None, "nights": None}

    # Ask Check-in Date
    while not details["date"]:
        user_input = listen("When is the check-in date?")
        if not user_input:
            continue 
        details["date"] = interpret_date(user_input)

    # Ask Number of Guests
    while not details["guests"]:
        user_input = listen("How many guests?")
        if not user_input:
            continue 
        details["guests"] = extract_number(user_input)

    # Ask Number of Nights
    while not details["nights"]:
        user_input = listen("How many nights?")
        if not user_input:
            continue
        details["nights"] = extract_number(user_input)

    # Confirm Booking
    speak(f"Room booked for {details['guests']} guest(s) on {details['date']} for {details['nights']} night(s).")

# General Knowledge Response

def handle_general_query(user_input):
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": user_input}],
            max_tokens=30,  # ~10-15 words
            temperature=0.5
        )
        answer = response.choices[0].message.content.strip()
        speak(answer)
    except:
        fallback_responses = [
            "I'm sorry, can't find that now.",
            "Unable to answer at this moment.",
            "Please ask again later."
        ]
        speak(random.choice(fallback_responses))

# Main Assistant

def run_assistant():
    speak("Hello! How can I assist you?")

    while True:
        user_input = listen()
        if not user_input:
            continue

        if any(word in user_input for word in TERMINATION_KEYWORDS):
            speak("Goodbye!")
            break

        if any(word in user_input for word in BOOKING_KEYWORDS):
            handle_booking()
            continue

        handle_general_query(user_input)

# Run
if __name__ == "__main__":
    run_assistant()
